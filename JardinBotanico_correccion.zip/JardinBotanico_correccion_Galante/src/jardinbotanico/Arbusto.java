
package jardinbotanico;


public class Arbusto extends Planta implements Podable {
    
    private static final int DEN_MIN = 1;
    private static final int DEN_MAX = 10;
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        validarDensidad(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public void podar(){
        System.out.println("Podando arbusto");
    }
    
    private void validarDensidad(int densidadFollaje){
        
        if(densidadFollaje < DEN_MIN || densidadFollaje > DEN_MAX){
            throw new RuntimeException("El minimo de densidad es 1 y el maximo es 10");
        }
    }

    @Override
    public String toString() {
        return super.toString() + "Arbusto{" + "densidadFollaje=" + densidadFollaje + '}';
    }
    
    
    
}
