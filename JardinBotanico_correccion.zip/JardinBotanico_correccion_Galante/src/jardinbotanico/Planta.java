
package jardinbotanico;

import java.util.Objects;


public abstract class Planta {
    
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    
    @Override
    public boolean equals(Object o){
        if(o == this){
        return true;
        }
        if(o == null || !(o instanceof Planta planta)){
            return false;
        }
        Planta otraPlanta = (Planta) o;
        return nombre.equals(otraPlanta.nombre) && ubicacion.equals(otraPlanta.ubicacion);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.nombre);
        hash = 89 * hash + Objects.hashCode(this.ubicacion);
        return hash;
    }
    
    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + '}';
    }

}
