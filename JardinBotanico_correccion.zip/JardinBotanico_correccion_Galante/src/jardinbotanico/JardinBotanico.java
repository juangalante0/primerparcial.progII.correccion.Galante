
package jardinbotanico;
import java.util.List;
import java.util.ArrayList;


public class JardinBotanico {
    
    private List<Planta> plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta){
        if (planta != null){
            if (plantas.contains(planta)){
                throw new PlantaRepetidaException();
            }
            plantas.add(planta);
        } else {
            throw new NullPointerException();
        }
    }
    
    public void mostrarPlantas(){
        for(Planta planta : plantas){
            System.out.println(planta);
        }
    }
    
    public void podarPlantas(){
       for(Planta planta : plantas){
           if(planta instanceof Podable podable){
                podable.podar();
           } else {
           System.out.println("La planta no se puede podar");}
       }
    }
}
