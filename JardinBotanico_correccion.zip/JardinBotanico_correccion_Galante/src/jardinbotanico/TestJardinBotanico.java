
package jardinbotanico;


public class TestJardinBotanico {

   
    public static void main(String[] args) {
        
        JardinBotanico jardin = new JardinBotanico();
        
        
        Arbol arbol_1 = new Arbol("roble", "norte", "templado", 5);
        Arbol arbol_2 = new Arbol("jacaranda", "norte", "templado", 7);
        Arbol arbol_3 = new Arbol("roble", "norte", "templado", 5);
        Arbusto arbusto_1 = new Arbusto("ficus", "norte", "templado", 5);
        Arbusto arbusto_2 = new Arbusto("libustrina", "norte", "templado", 6);
        Arbusto arbusto_3 = new Arbusto("KKK", "norte", "templado", 5);
        Flor flor_1 = new Flor("Rosa", "sur", "calor",TemporadaFlorecimiento.INVIERNO);
        Flor flor_2 = new Flor("Jazmin", "norte", "calor", TemporadaFlorecimiento.VERANO);
        Flor flor_3 = new Flor("Rosa", "norte", "calor", TemporadaFlorecimiento.OTONIO);
        
        
        try{
        jardin.agregarPlanta(flor_1);
        jardin.agregarPlanta(flor_2);
        jardin.agregarPlanta(flor_3);
        jardin.agregarPlanta(arbol_1);
        jardin.agregarPlanta(arbol_2);
        jardin.agregarPlanta(arbusto_1);
        jardin.agregarPlanta(arbusto_2);
        jardin.agregarPlanta(arbusto_3);
        jardin.agregarPlanta(arbol_3);
        } catch (PlantaRepetidaException ex){
            System.out.println(ex.getMessage());
        } 
       
        
        System.out.println("---------------------------------");
        
        jardin.mostrarPlantas();
        
        System.out.println("---------------------------------");
        
        jardin.podarPlantas();

    }
    
}
