
package jardinbotanico;


public interface Podable {
    
    public abstract void podar();
    
}
