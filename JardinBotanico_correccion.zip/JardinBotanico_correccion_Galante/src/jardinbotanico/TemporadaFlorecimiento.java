
package jardinbotanico;


public enum TemporadaFlorecimiento {
    
    PRIVAMERA,
    OTONIO,
    INVIERNO,
    VERANO
    
}
